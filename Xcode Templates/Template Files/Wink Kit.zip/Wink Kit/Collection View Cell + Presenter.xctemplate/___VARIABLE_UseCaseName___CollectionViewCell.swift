//___FILEHEADER___

import WinkKit

class ___VARIABLE_UseCaseName___CollectionViewCell: WKCollectionViewCell<___VARIABLE_UseCaseName___Presenter> {
    
}

extension ___VARIABLE_UseCaseName___CollectionViewCell: ___VARIABLE_UseCaseName___View {
    
}
