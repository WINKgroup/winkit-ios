//___FILEHEADER___

import WinkKit

class ___VARIABLE_UseCaseName___TableViewCell: WKTableViewCell<___VARIABLE_UseCaseName___Presenter> {
    
}

extension ___VARIABLE_UseCaseName___TableViewCell: ___VARIABLE_UseCaseName___View {
    
}
