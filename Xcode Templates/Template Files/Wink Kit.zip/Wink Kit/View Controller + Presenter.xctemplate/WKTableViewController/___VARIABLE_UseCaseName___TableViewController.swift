//___FILEHEADER___

import WinkKit

class ___VARIABLE_UseCaseName___ViewController: WKTableViewController<___VARIABLE_UseCaseName___Presenter> {
    
}

extension ___VARIABLE_UseCaseName___ViewController: ___VARIABLE_UseCaseName___View {
    
}
